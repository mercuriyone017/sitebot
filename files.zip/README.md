# Mirage Game Club — Telegram Bot

## Qanday ishlaydi?
1. Mijoz saytda bron qiladi
2. Adminга (824354773) Telegram xabari keladi + ✅ / ❌ tugmalar
3. Admin "Tasdiqlash" bosadi → mijozga avtomatik xabar ketadi

## ⚠️ MUHIM ESLATMA
Mijozga avtomatik xabar faqat u avval @miragesitebot ga `/start` 
yuborganda ishlaydi. Aks holda bot admin ga xabar matnini ko'rsatadi
va siz qo'lda telefon qilasiz.

## Railway.app da joylashtirish (BEPUL)

### 1. GitHub ga yuklang
1. github.com ga boring → "New repository" → "mirage-bot"
2. Uchala faylni (bot.py, requirements.txt, Procfile) yuklang

### 2. Railway ga ulang
1. railway.app ga boring → GitHub bilan kiring
2. "New Project" → "Deploy from GitHub repo" → "mirage-bot" tanlang
3. Deploy tugmasi → 2 daqiqada bot ishlaydi!

### 3. Saytdagi webhook URL ni yangilang
Railway da loyiha URL si beriladi, masalan:
`https://mirage-bot-production.up.railway.app`

Shu URL ni saytdagi index.html dagi `WEBHOOK_URL` ga qo'ying.

## Saytni bot bilan ulash
index.html da quyidagi qatorni toping va URL ni yangilang:
```
const WEBHOOK_URL = 'https://YOUR-RAILWAY-URL.up.railway.app/webhook/bron';
```

## Tekshirish
Bot ishlayotganini tekshirish:
`https://YOUR-RAILWAY-URL.up.railway.app/health`
